data_station:
Stations used in the study

data_local:
Local travel times used in the study

data_tele:
Relative travel-time residuals used in the study
